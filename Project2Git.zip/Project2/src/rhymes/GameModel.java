package rhymes;

import java.util.ArrayList;
import rhymes.dictionary.RhymingDictionary;

public class GameModel {

	private GUI gui; 
	private int score;
	private String referenceWord;
	private RhymingDictionary rhymes;
	private ArrayList<String> choices;

	public GameModel(String dictionaryFileName) {
		rhymes = new RhymingDictionary(dictionaryFileName);
		referenceWord = rhymes.randomWord();
		choices = rhymes.getChoices(referenceWord);
		score = 0;
		}

	public void setGUI(GUI gui) {
		this.gui = gui;
	}
	
	public void makeChoice(String userInput) {
		//score goes up or goes down the same each turn depending on whether the game 
		//is answered correctly or not. A new word is presented each turn.
		if(rhymes.isRhyme(referenceWord, userInput)) {
			score += 1;
		}else {
			score -= 1;
			//May not want the score to go below 0.
		}
		referenceWord = rhymes.randomWord();
		choices = rhymes.getChoices(referenceWord);
		
		gui.update();
	}
	
	
	public int getScore() {
		return score;
	}
	
	public String getGivenWord() {
		return referenceWord;
	}
	
	public ArrayList<String> getChoices(){
		return choices;
	}
	
}
