package rhymes;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class GUI implements Runnable{
	
	
	private JFrame frame;
	private JPanel mainPanel;
	private GameModel model;
	private JLabel referenceWord, score;
	private JButton choice1, choice2, choice3, choice4;
	
//	public void runGUI(){
//		frame = new JFrame("GUI");
//		frame.add(getWordPanel());
//		frame.setSize(500, 140);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		frame.setVisible(true);
//	}
	
	public GUI (GameModel param) {
	
		model = param;
		model.setGUI(this);	
		JPanel mainPanel = new JPanel();
		this.mainPanel = mainPanel;
		
		score = new JLabel();
		mainPanel.setLayout(new BorderLayout());
		
		mainPanel.add(getWordPanel(), BorderLayout.NORTH);
		mainPanel.add(getChoicesPanel(), BorderLayout.CENTER);
		mainPanel.add(getScorePanel(), BorderLayout.SOUTH);
//		update();
	}
	
	
	public ActionListener act(String s) {
		return new ActionListener() {
			
			private String text = s;

			@Override
			public void actionPerformed(ActionEvent arg0) {
				model.makeChoice(text);
			}	
		};
	}
	
	

	//North Panel
	public JPanel getWordPanel() {
		JPanel panelWP = new JPanel();
//		JLabel label = new JLabel(referenceWord);
		referenceWord = new JLabel(model.getGivenWord());
		panelWP.add(referenceWord);
		return panelWP;
	}

	//Center Panel
	public JPanel getChoicesPanel() {
		JPanel panelCP = new JPanel();
		choice1 = new JButton(model.getChoices().get(0));
		choice2 = new JButton(model.getChoices().get(1));
		choice3 = new JButton(model.getChoices().get(2));
		choice4 = new JButton(model.getChoices().get(3));
		
//		choice1.addActionListener(act(model.getChoices().get(0)));
//		choice2.addActionListener(act(model.getChoices().get(1)));
//		choice3.addActionListener(act(model.getChoices().get(2)));
//		choice4.addActionListener(act(model.getChoices().get(3)));
		
		choice1.addMouseListener(new AnswerListener(choice1, model, this));
		choice2.addMouseListener(new AnswerListener(choice2, model, this));
		choice3.addMouseListener(new AnswerListener(choice3, model, this));
		choice4.addMouseListener(new AnswerListener(choice4, model, this));
		
		
		
		panelCP.add(choice1);
		panelCP.add(choice2);
		panelCP.add(choice3);
		panelCP.add(choice4);
		
		
		return panelCP;
	}

	//South Panel
	public JPanel getScorePanel() {
		JPanel panelSP = new JPanel();
		score = new JLabel("Score:" + model.getScore());
		panelSP.add(score);
		return panelSP;
	}
	
	public void update() {
//		mainPanel.removeAll();
//		mainPanel.add(getWordPanel(), BorderLayout.NORTH);
//		mainPanel.add(getChoicesPanel(), BorderLayout.CENTER);
//		mainPanel.add(getScorePanel(), BorderLayout.SOUTH);
		
		
		referenceWord.setText(model.getGivenWord());
		
		
		choice1.setText(model.getChoices().get(0));
//		choice1.removeActionListener(choice1.getActionListeners()[0]);
//		choice1.addActionListener(act(model.getChoices().get(0)));
		
		choice2.setText(model.getChoices().get(1));
//		choice2.removeActionListener(choice2.getActionListeners()[0]);
//		choice2.addActionListener(act(model.getChoices().get(1)));
		
		choice3.setText(model.getChoices().get(2));
//		choice3.removeActionListener(choice3.getActionListeners()[0]);
//		choice3.addActionListener(act(model.getChoices().get(2)));
		
		choice4.setText(model.getChoices().get(3));
//		choice4.removeActionListener(choice4.getActionListeners()[0]);
//		choice4.addActionListener(act(model.getChoices().get(3)));
		

		score.setText("Score:" + model.getScore());
		
	
		
		if(frame != null) {
			frame.pack();
			frame.repaint();
		}
		
		
		//error here cause you cant resize the jframe to change values shown

	}
	
	@Override
	public void run() {
		JFrame frame = new JFrame("Rhymes");
		this.frame = frame;
		
		frame.setContentPane(mainPanel);


		

		frame.pack();
		frame.repaint();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
