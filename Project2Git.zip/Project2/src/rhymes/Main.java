package rhymes;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Main {
	
	

	public static void main(String[] args) {
		GUI gui = new GUI(new GameModel("rhymingDictionary.txt"));
		SwingUtilities.invokeLater(gui);
		
	}
	
	
}
