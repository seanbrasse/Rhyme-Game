package rhymes.dictionary;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class RhymingDictionary {

	private HashMap<String, String> rhymes;
	//private ArrayList<String> lastVowelAndMore;

	public RhymingDictionary(String filename) {
		rhymes = new HashMap<>();
		//vowels = new ArrayList<>();
		String lastRhyme = "";
		try {
			for(String line: Files.readAllLines(Paths.get(filename))) {
				String [] a = line.split("  ");
				String word = a[0];
				String[] pronounce = a[1].split(" ");

				ArrayList<String> integers = new ArrayList<String>();
				integers.add("0");				
				integers.add("1");
				integers.add("2");

				int rhymeIdx = 0;

				for(int i = pronounce.length-1; i >= 0 ; i--) {
					boolean check = false;
					for(String numbers: integers) {
						if(pronounce[i].endsWith(numbers)){
							String removedInt = pronounce[i].substring(0, pronounce[i].length()-1);
							lastRhyme = removedInt; 
							rhymeIdx = i;
							check = true;

							break;
						}

					}
					if(check) {
						break;
					}
				}


				for(int i = rhymeIdx + 1; i < pronounce.length; i++) {
					lastRhyme = lastRhyme + " " + pronounce[i]; 
				}

				rhymes.put(word.toLowerCase(), lastRhyme);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean isRhyme(String input1, String input2) {
		if(rhymes.get(input1.toLowerCase()).equals(rhymes.get(input2.toLowerCase()))) {
			return true;
		}		

		return false;
	}

	//Rhyming Dictionary Testing	
	//	public static void main(String[] args) {
	//		RhymingDictionary x = new RhymingDictionary("rhymingDictionary.txt");
	//		String winter = "winter";
	//		String winner = "winner";
	//		System.out.println(x.isRhyme(winter, winner));
	//	}


	public String randomWord() {

		String key ="";
		ArrayList<String> randomWords = new ArrayList<String>();
		for(String k: rhymes.keySet()) {
			randomWords.add(k);
			Collections.shuffle(randomWords);
			//Collections.shuffle((List<?>) rhymes.keySet());
			key = randomWords.get(0);
		}
		//		int rand = (int)(Math.random()*rhymes.size());
		//		key = (String) rhymes.keySet().toArray()[rand];
		return key;
	}

	public ArrayList<String> getChoices (String randomWord){
		ArrayList<String> randomOptions = new ArrayList<String>();
		ArrayList<String> rhyme = new ArrayList<String>();
		ArrayList<String> dontRhyme = new ArrayList<String>();
		ArrayList<String> allOptions = new ArrayList<String>(rhymes.keySet());

		for(String s: allOptions) {
			if(!s.equals(randomWord)){
				if(!isRhyme(s, randomWord)) {
					dontRhyme.add(s);
				} else {
					rhyme.add(s);
				}
			}
		}
		Collections.shuffle(dontRhyme);
		Collections.shuffle(rhyme);
		
		randomOptions.add(dontRhyme.get(0));
		randomOptions.add(dontRhyme.get(1));
		randomOptions.add(dontRhyme.get(2));
		randomOptions.add(rhyme.get(0));
		Collections.shuffle(randomOptions);
		

		return randomOptions;
	}


//	public static void main(String[] args) {
//		RhymingDictionary x = new RhymingDictionary("rhymingDictionary.txt");
//		System.out.println(x.getChoices("written"));
		//System.out.println(userOptions.size());
	//}



}




