package rhymes;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;

public class AnswerListener implements MouseListener{
	
	private JButton button;
	private GameModel model;
	private GUI gui;
	
	
	public AnswerListener(JButton button, GameModel model, GUI gui) {
		this.button = button;
		this.model = model;
		this.gui = gui;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		button.setForeground(Color.BLUE);
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		button.setForeground(Color.BLACK);
		
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		button.setForeground(Color.WHITE);
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		button.setForeground(Color.BLUE);
		String s = button.getText();
		model.makeChoice(s);
		
	}

}
